# ArtBridge by Voice of Piece

## LA artist application → local CSV (before the database)

New artists (Los Angeles and beyond) apply at **`#apply`**. The header "Join the bridge" button and the closing "Create your artist profile" button both open it.

The form asks:
1. **About you**: profile questions kept from the original Voice of Piece application.
2. **Matching questions**: the same 8 questions and option lists Tanzanian artists answer (`application-schema.js`).
3. **The question**: "What would you like to make with an artist on the other side of the world?"
4. **Age**: under-18 applicants must add a parent/guardian name, email and consent.
5. Optional extra questions (collapsed).

It works in English, 한국어 and Kiswahili, and saves a draft as the artist types.

### Option A: save straight to a CSV file (recommended)

    node server.js

Open http://localhost:8080/#apply. Every submission is appended to **`data/la-applications.csv`**. This needs Node.js and no packages.
Studio › My data also offers "Download CSV from server".

### Option B: no server (Live Server, file, or static hosting)

Submissions are kept **in that browser only**. Download them from **Studio › My data › LA artist applications › Download applications CSV**.
Use this for sign-ups on one shared laptop, for example at an event. On a public website, each applicant's answers would stay in their own browser, so do not use Option B to collect applications online. Use the database once it exists.

### CSV format
- One row per application. Column order is in `application-schema.js` (`COLUMNS`).
- Multi-choice answers are joined with `|`, the same as `data/sample-artists.csv`.
- The file is UTF-8 with BOM, so Excel opens Korean and Kiswahili text correctly.
- Cells that start with `= + - @` get a leading `'` so spreadsheets don't run them as formulas.
- The CSV contains personal information. Keep it private. `data/.gitignore` keeps it out of git.

---

# Voice of Piece — LA × Tanzania Artist Collaboration

Local prototype for the Congressional App Challenge website concept.

## Run locally with VS Code Live Server

1. Unzip this folder.
2. Open the `cac-homepage` folder in VS Code.
3. Install the **Live Server** extension if needed.
4. Right-click `index.html` and choose **Open with Live Server**.
5. The site should open at an address similar to `http://127.0.0.1:5500/`.

## What is included

- Home page with an LA × Tanzania artistic city hero image
- About the Project section
- One Line, Two Worlds collaboration section
- Artist / artwork photo gallery using supplied project images
- Join as an Artist section
- English / Kiswahili artist application with language switching, organized into 9 sections
- Local draft saving via browser `localStorage`
- Test submission + downloadable JSON response
- Link to the older Google Form
- Responsive layout for desktop, tablet, and mobile

## Important about the application form

This is a **local prototype**. The HTML form does not send submissions to a database or Google Sheet. A test submission is saved only in the current browser. Before public launch, connect the form to a backend, Google Sheets, or another submission service.

The older Google Form is linked from the application section as a live fallback/reference. The local form follows the earlier Voice of Piece application structure while adding the current LA × Tanzania research questions.

## Files

- `index.html` — page structure and content
- `styles.css` — all responsive styling
- `script.js` — navigation, language toggle, validation, local draft storage, and test response download
- `assets/` — compressed project images used by the website
